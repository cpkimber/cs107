#! /home/cam/anaconda3/bin/python3
"""
file: horoscope.py
Cameron Kimber
date: 2018-10-24
Class: CSE107
Assignment:
"""
import date


signs = {"Aries": ["March, 21, 1999", "April, 20, 1999"],
          "Taurus": ["April, 21, 1999", "May 21, 1999"],}


def main():

if __name__ == "__main__":
	main()
