#! /home/cam/anaconda3/bin/python3
"""
file: nested.py
Cameron Kimber
date: 2018-11-04
Class: CSE107
Assignment:
"""

def element_of(x):


def filter_by_depth(x):


def main():

if __name__ == "__main__":
	main()
